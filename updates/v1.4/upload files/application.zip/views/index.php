<?php include'include/header.php';?>
  <?= $main_content;?>
<?php include'include/footer.php';?>