
<div class="modal fade" id="google-cal-data" role="dialog">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">        
        <h4 class="modal-title">Google Calendar</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <span id="render-google-cal-data"><div class="text-center"><i class="fa fa-spinner fa-pulse fa-5x fa-fw"></i></div></span>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>    
  </div>
</div>