<?php include'include/header2.php';?>
  <?= $main_content;?>
<?php include'include/footer2.php';?>
