<div class="text-center bg-greys col-12 d-flex align-items-center justify-content-center">
    <div class="pt-8 pb-8">
        <h2 class="text-muted mb-1"><i class="bi bi-folder2-open"></i></h2>
        <p class="text-muted"><span><?php echo trans('no-data-found') ?></span></p>
    </div>
</div>