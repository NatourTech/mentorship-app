<?php include'include/header.php';?>
<?php include'include/left_sideber.php';?>
  <?= $main_content;?>
<?php include'include/footer.php';?>