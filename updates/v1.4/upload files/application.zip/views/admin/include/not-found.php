<div class="rows mt-2">
  <div class="col-md-12s">
    <div class="empty-data py-5 text-center bg-white rounded-md" data-aos="fade-up">
      <h2 class="text-muted mb-2"><i class="lni lni-empty-file"></i></h2>
      <p class="mt-4"><?php echo trans('no-data-found') ?></p>
    </div>
  </div>
</div>